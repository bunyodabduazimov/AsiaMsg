import React from 'react';
import { Sidebar } from './Sidebar';
import { Topbar } from './Topbar';
import { AppState, ActiveView } from '../types';

interface LayoutProps {
  state: AppState;
  onViewChange: (view: ActiveView) => void;
  onSearchChange: (query: string) => void;
  onLanguageChange: (lang: 'RU' | 'EN') => void;
  onThemeChange: (theme: 'light' | 'dark') => void;
  children: React.ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({
  state,
  onViewChange,
  onSearchChange,
  onLanguageChange,
  onThemeChange,
  children
}) => {
  const isDark = state.theme === 'dark';
  return (
    <div className={`flex h-screen w-screen overflow-hidden font-sans antialiased transition-colors duration-200 ${isDark ? 'dark bg-slate-950 text-slate-100' : 'bg-slate-50 text-gray-800'}`}>
      {/* Persistent Left Sidebar */}
      <Sidebar 
        activeView={state.activeView}
        onViewChange={onViewChange}
        language={state.language}
        theme={state.theme}
      />

      {/* Main Workspace Frame */}
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        {/* Consistent Topbar */}
        <Topbar 
          state={state}
          onSearchChange={onSearchChange}
          onLanguageChange={onLanguageChange}
          onThemeChange={onThemeChange}
        />

        {/* Scrollable page body */}
        <main className={`flex-1 overflow-y-auto p-8 transition-colors duration-200 ${isDark ? 'bg-slate-900/20' : 'bg-slate-100/70'}`}>
          <div className="max-w-7xl mx-auto h-full">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};
