import React, { useState } from 'react';
import { 
  Search, 
  Bell, 
  ChevronDown, 
  Sun, 
  Moon, 
  User, 
  LogOut, 
  ShieldCheck, 
  MessageSquareCode
} from 'lucide-react';
import { AppState } from '../types';

interface TopbarProps {
  state: AppState;
  onSearchChange: (query: string) => void;
  onLanguageChange: (lang: 'RU' | 'EN') => void;
  onThemeChange: (theme: 'light' | 'dark') => void;
  onProfileClick?: () => void;
}

export const Topbar: React.FC<TopbarProps> = ({
  state,
  onSearchChange,
  onLanguageChange,
  onThemeChange,
}) => {
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const isRu = state.language === 'RU';

  const mockNotifications = [
    { id: 1, text: isRu ? 'Инстанс "Sales Bot" успешно подключен' : 'Instance "Sales Bot" successfully connected', time: '1 мин. назад' },
    { id: 2, text: isRu ? 'Достигнуто 25% месячного лимита сообщений' : 'Reached 25% of monthly message limit', time: '15 мин. назад' },
    { id: 3, text: isRu ? 'Обнаружена ошибка webhook доставки на CRM Sync' : 'Webhook delivery error detected on CRM Sync', time: '1 ч. назад' },
  ];

  const isDark = state.theme === 'dark';

  return (
    <header className="h-20 border-b border-gray-100 dark:border-slate-800 bg-white dark:bg-slate-900 px-8 flex items-center justify-between sticky top-0 z-40 transition-colors duration-200">
      {/* Search Input Box */}
      <div className="w-96 relative">
        <div className="absolute inset-y-0 left-3.5 flex items-center pointer-events-none text-gray-400">
          <Search className="w-4.5 h-4.5" />
        </div>
        <input
          type="text"
          value={state.searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder={isRu ? "Поиск..." : "Search..."}
          className="w-full bg-gray-50/60 dark:bg-slate-950/60 border border-gray-100 dark:border-slate-800 rounded-xl py-2.5 pl-10 pr-14 text-sm text-gray-800 dark:text-white placeholder-gray-400 hover:border-gray-200 focus:outline-hidden focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-50/40 dark:focus:ring-blue-950/40 transition-all duration-150"
        />
        <div className="absolute right-3.5 inset-y-0 flex items-center pointer-events-none">
          <kbd className="hidden sm:inline-flex items-center gap-0.5 h-5 select-none px-1.5 font-sans font-medium text-[10px] text-gray-400 dark:text-slate-500 bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-800 rounded-md shadow-3xs">
            <span className="text-xs">⌘</span>K
          </kbd>
        </div>
      </div>

      {/* Action Indicators & User Controls */}
      <div className="flex items-center gap-6">
        {/* Language Controller */}
        <div className="flex bg-gray-50 dark:bg-slate-950 p-1 rounded-lg border border-gray-200/50 dark:border-slate-800">
          <button
            onClick={() => onLanguageChange('RU')}
            className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-all duration-150 cursor-pointer ${
              state.language === 'RU'
                ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-3xs'
                : 'text-gray-400 hover:text-gray-700 dark:hover:text-slate-300'
            }`}
          >
            RU
          </button>
          <button
            onClick={() => onLanguageChange('EN')}
            className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-all duration-150 cursor-pointer ${
              state.language === 'EN'
                ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-3xs'
                : 'text-gray-400 hover:text-gray-700 dark:hover:text-slate-300'
            }`}
          >
            EN
          </button>
        </div>

        {/* Light / Dark Mode Toggle Button */}
        <div 
          onClick={() => onThemeChange(state.theme === 'light' ? 'dark' : 'light')}
          className="flex items-center bg-gray-50 dark:bg-slate-950 border border-gray-200/50 dark:border-slate-800 rounded-full p-1 cursor-pointer w-16 transition-colors duration-200 relative h-8 shrink-0"
        >
          {/* Slider background dot */}
          <div 
            className={`absolute w-6 h-6 rounded-full bg-white dark:bg-slate-900 border border-gray-200/70 dark:border-slate-800 shadow-3xs flex items-center justify-center transition-all duration-200 ${
              state.theme === 'light' ? 'left-1' : 'left-9'
            }`}
          >
            {state.theme === 'light' ? (
              <Sun className="w-3.5 h-3.5 text-amber-500 fill-amber-50" />
            ) : (
              <Moon className="w-3.5 h-3.5 text-blue-400 fill-blue-950/50" />
            )}
          </div>
          {/* Background icons in fixed position */}
          <div className="w-full flex justify-between px-1.5 text-gray-400 pointer-events-none">
            <Sun className="w-3.5 h-3.5" />
            <Moon className="w-3.5 h-3.5" />
          </div>
        </div>

        {/* Interactive Notifications Bell */}
        <div className="relative">
          <button 
            onClick={() => setShowNotifications(!showNotifications)}
            className="w-10 h-10 rounded-xl bg-gray-50 dark:bg-slate-950 hover:bg-gray-100 dark:hover:bg-slate-800 border border-gray-100 dark:border-slate-800 flex items-center justify-center text-gray-500 dark:text-slate-400 hover:text-gray-900 dark:hover:text-white transition-all duration-150 relative cursor-pointer"
          >
            <Bell className="w-4.5 h-4.5" />
            {state.notificationCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-rose-500 text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center border-2 border-white dark:border-slate-900 animate-pulse">
                {state.notificationCount}
              </span>
            )}
          </button>

          {showNotifications && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setShowNotifications(false)} />
              <div className="absolute right-0 mt-2.5 w-80 bg-white dark:bg-slate-900 border border-gray-100 dark:border-slate-800 rounded-2xl shadow-xl z-50 p-4 divide-y divide-gray-50 dark:divide-slate-800">
                <div className="pb-2.5 flex justify-between items-center">
                  <span className="font-semibold text-sm text-gray-900 dark:text-white">
                    {isRu ? 'Уведомления' : 'Notifications'}
                  </span>
                  <span className="text-[10px] bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 font-bold px-2 py-0.5 rounded-full">
                    {state.notificationCount} {isRu ? 'Новых' : 'New'}
                  </span>
                </div>
                <div className="space-y-3 pt-3 max-h-64 overflow-y-auto">
                  {mockNotifications.map((n) => (
                    <div key={n.id} className="text-xs text-gray-600 dark:text-slate-300 pb-1 flex flex-col gap-1">
                      <p>{n.text}</p>
                      <span className="text-[10px] text-gray-400 dark:text-slate-500 font-mono">{n.time}</span>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>

        {/* User Account Controls */}
        <div className="relative">
          <button
            onClick={() => setShowProfileMenu(!showProfileMenu)}
            className="flex items-center gap-3 hover:opacity-90 transition-opacity duration-150 cursor-pointer"
          >
            {/* Avatar Pill matching picture */}
            <div className="w-10 h-10 rounded-xl bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-400 border border-purple-200 dark:border-purple-800/60 flex items-center justify-center font-bold text-sm select-none">
              {state.userProfile.name.charAt(0)}
            </div>

            <div className="text-left hidden lg:block">
              <span className="block text-sm font-semibold text-gray-800 dark:text-slate-200 leading-tight">
                {state.userProfile.name}
              </span>
              <span className="block text-[10px] text-gray-400 dark:text-slate-500 font-mono">
                {state.userProfile.email}
              </span>
            </div>

            <ChevronDown className="w-4 h-4 text-gray-400 hidden sm:block" />
          </button>

          {showProfileMenu && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setShowProfileMenu(false)} />
              <div className="absolute right-0 mt-2.5 w-56 bg-white dark:bg-slate-900 border border-gray-100 dark:border-slate-800 rounded-2xl shadow-xl z-50 py-2">
                <div className="px-4 py-2 border-b border-gray-50 dark:border-slate-800 pb-2.5">
                  <span className="block text-xs text-gray-400">{isRu ? 'Роль' : 'Role'}</span>
                  <span className="block text-xs font-semibold text-blue-600 dark:text-blue-400">{isRu ? 'Администратор' : 'Administrator'}</span>
                </div>
                
                <div className="p-1 space-y-0.5">
                  <button className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium text-gray-600 dark:text-slate-300 hover:text-gray-900 dark:hover:text-white hover:bg-gray-50 dark:hover:bg-slate-800 text-left cursor-pointer">
                    <User className="w-4 h-4 text-gray-400" />
                    {isRu ? 'Мой аккаунт' : 'My Account'}
                  </button>
                  <button className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium text-gray-600 dark:text-slate-300 hover:text-gray-900 dark:hover:text-white hover:bg-gray-50 dark:hover:bg-slate-800 text-left cursor-pointer">
                    <ShieldCheck className="w-4 h-4 text-gray-400" />
                    {isRu ? 'Безопасность' : 'Security'}
                  </button>
                  <button className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium text-gray-600 dark:text-slate-300 hover:text-gray-900 dark:hover:text-white hover:bg-gray-50 dark:hover:bg-slate-800 text-left cursor-pointer">
                    <MessageSquareCode className="w-4 h-4 text-gray-400" />
                    {isRu ? 'Документация API' : 'API Reference'}
                  </button>
                </div>

                <div className="border-t border-gray-50 dark:border-slate-800 mt-1.5 pt-1.5 px-1">
                  <button className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 text-left cursor-pointer">
                    <LogOut className="w-4 h-4" />
                    {isRu ? 'Выйти' : 'Sign Out'}
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
};
