import React from 'react';
import { 
  LayoutDashboard, 
  Layers, 
  MessageSquare, 
  Key, 
  Webhook, 
  FileText, 
  Settings, 
  MessageCircle,
  TrendingUp
} from 'lucide-react';
import { ActiveView } from '../types';

interface SidebarProps {
  activeView: ActiveView;
  onViewChange: (view: ActiveView) => void;
  language: 'RU' | 'EN';
  messageLimitCount?: number;
  theme?: 'light' | 'dark';
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeView,
  onViewChange,
  language,
  messageLimitCount = 148250,
  theme = 'light'
}) => {
  const isRu = language === 'RU';
  const isDark = theme === 'dark';

  // Navigation items without "Projects"
  const navItems = [
    { id: 'overview' as ActiveView, labelRu: 'Обзор', labelEn: 'Overview', icon: LayoutDashboard },
    { id: 'instances' as ActiveView, labelRu: 'Инстансы', labelEn: 'Instances', icon: Layers },
    { id: 'messages' as ActiveView, labelRu: 'Сообщения', labelEn: 'Messages', icon: MessageSquare },
    { id: 'tokens' as ActiveView, labelRu: 'API токены', labelEn: 'API Tokens', icon: Key },
    { id: 'webhooks' as ActiveView, labelRu: 'Webhooks', labelEn: 'Webhooks', icon: Webhook },
    { id: 'logs' as ActiveView, labelRu: 'Логи', labelEn: 'Logs', icon: FileText },
    { id: 'settings' as ActiveView, labelRu: 'Настройки', labelEn: 'Settings', icon: Settings },
  ];

  const percent = Math.round((messageLimitCount / 500000) * 100);

  return (
    <aside className="w-64 border-r border-gray-100 dark:border-slate-800 bg-white dark:bg-slate-900 h-screen flex flex-col justify-between shrink-0 sticky top-0 transition-colors duration-200">
      <div className="flex flex-col flex-1 pt-6 overflow-y-auto">
        {/* Brand Logo matching the header design */}
        <div className="px-6 flex items-center gap-2.5 mb-8">
          <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-sm shadow-blue-200 dark:shadow-none">
            <MessageCircle className="w-6.5 h-6.5 fill-white" />
          </div>
          <span className="text-xl font-bold tracking-tight text-gray-900 dark:text-white flex items-center">
            Asia<span className="text-blue-600 font-extrabold">Msg</span>
          </span>
        </div>

        {/* Navigation Menu */}
        <nav className="px-3 space-y-1 flex-1">
          {navItems.map((item) => {
            const IconComponent = item.icon;
            const isActive = activeView === item.id;
            const label = isRu ? item.labelRu : item.labelEn;

            return (
              <button
                key={item.id}
                onClick={() => onViewChange(item.id)}
                className={`w-full flex items-center gap-3.5 px-4.5 py-3 rounded-xl text-sm font-medium transition-all duration-150 group cursor-pointer ${
                  isActive
                    ? 'bg-blue-50/70 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 font-semibold shadow-2xs'
                    : 'text-gray-500 dark:text-slate-400 hover:text-gray-900 dark:hover:text-white hover:bg-gray-50 dark:hover:bg-slate-800'
                }`}
              >
                <IconComponent
                  className={`w-5 h-5 transition-transform duration-150 group-hover:scale-105 ${
                    isActive ? 'text-blue-600 dark:text-blue-400' : 'text-gray-400 dark:text-slate-500 group-hover:text-gray-600 dark:group-hover:text-slate-300'
                  }`}
                />
                <span>{label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      {/* Sidebar Footer Metrics and Info */}
      <div className="p-4 border-t border-gray-100 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4 transition-colors duration-200">
        {/* Subscription Plan Block */}
        <div className="bg-gray-50/70 dark:bg-slate-950/40 rounded-2xl p-4 border border-gray-100 dark:border-slate-800/80">
          <div className="flex items-center justify-between text-xs mb-3">
            <span className="text-gray-500 dark:text-slate-400 font-medium">
              {isRu ? 'Тариф:' : 'Plan:'} <span className="text-gray-900 dark:text-white font-bold">Business</span>
            </span>
            <button className="text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 font-semibold transition-colors duration-150 text-[11px] underline">
              {isRu ? 'Улучшить' : 'Upgrade'}
            </button>
          </div>

          <div className="space-y-1.5">
            <div className="flex justify-between text-[11px] font-medium text-gray-400 dark:text-slate-500">
              <span>{isRu ? 'Сообщений' : 'Messages'}</span>
              <span className="text-gray-700 dark:text-slate-300 font-semibold">{percent}%</span>
            </div>
            {/* Progress bar */}
            <div className="w-full bg-gray-200/80 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div 
                className="bg-blue-600 dark:bg-blue-500 h-1.5 rounded-full transition-all duration-500"
                style={{ width: `${percent}%` }}
              />
            </div>
            <div className="text-[10px] text-gray-400 dark:text-slate-500 font-mono mt-1">
              {messageLimitCount.toLocaleString('ru-RU')} / 500 000
            </div>
          </div>
        </div>

        {/* Brand Copyright */}
        <div className="px-2 text-[11px] text-gray-400 dark:text-slate-500 leading-relaxed font-medium">
          <div>© 2025 AsiaMsg</div>
          <div className="text-[10px] text-gray-300 dark:text-slate-600">{isRu ? 'Все права защищены' : 'All rights reserved'}</div>
        </div>
      </div>
    </aside>
  );
};
