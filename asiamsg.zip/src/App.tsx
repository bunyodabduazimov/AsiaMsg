import React, { useState } from 'react';
import { Layout } from './components/Layout';
import { OverviewView } from './components/views/OverviewView';
import { InstancesView } from './components/views/InstancesView';
import { MessagesView } from './components/views/MessagesView';
import { TokensView } from './components/views/TokensView';
import { WebhooksView } from './components/views/WebhooksView';
import { LogsView } from './components/views/LogsView';
import { SettingsView } from './components/views/SettingsView';
import { AppState, ActiveView, Instance, Message, ApiToken, Webhook, LogEntry } from './types';
import { 
  initialInstances, 
  initialMessages, 
  initialTokens, 
  initialWebhooks, 
  initialLogs 
} from './mockData';
import { Smartphone, Check, X, ShieldAlert, Plus } from 'lucide-react';

export default function App() {
  // Global React state
  const [state, setState] = useState<AppState>({
    activeView: 'overview',
    language: 'RU',
    theme: 'light',
    userProfile: {
      name: 'Администратор',
      email: 'admin@asiamsg.com'
    },
    instances: initialInstances,
    messages: initialMessages,
    tokens: initialTokens,
    webhooks: initialWebhooks,
    logs: initialLogs,
    selectedInstanceId: 'inst-01', // Preselect first
    selectedMessageId: 'msg-01', // Preselect first
    selectedTokenId: 'tok-01', // Preselect first
    selectedWebhookId: 'wh-01', // Preselect first
    selectedLogId: 'log-01', // Preselect first
    searchQuery: '',
    notificationCount: 3
  });

  // Modal State for adding WhatsApp number
  const [showAddNumberModal, setShowAddNumberModal] = useState(false);
  const [newNumName, setNewNumName] = useState('');
  const [newNumPhone, setNewNumPhone] = useState('+7 900 ');
  const [newNumProvider, setNewNumProvider] = useState('Baileys');

  // Success Notification Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleViewChange = (view: ActiveView) => {
    setState(prev => ({ 
      ...prev, 
      activeView: view,
      // Clear selected details so they adapt nicely to the page
      selectedInstanceId: view === 'instances' ? prev.selectedInstanceId || 'inst-01' : prev.selectedInstanceId,
      selectedMessageId: view === 'messages' ? prev.selectedMessageId || 'msg-01' : prev.selectedMessageId,
      selectedTokenId: view === 'tokens' ? prev.selectedTokenId || 'tok-01' : prev.selectedTokenId,
      selectedWebhookId: view === 'webhooks' ? prev.selectedWebhookId || 'wh-01' : prev.selectedWebhookId,
      selectedLogId: view === 'logs' ? prev.selectedLogId || 'log-01' : prev.selectedLogId
    }));
  };

  const handleSearchChange = (query: string) => {
    setState(prev => ({ ...prev, searchQuery: query }));
  };

  const handleLanguageChange = (lang: 'RU' | 'EN') => {
    setState(prev => ({ ...prev, language: lang }));
    triggerToast(lang === 'RU' ? 'Язык изменен на Русский' : 'Language set to English');
  };

  const handleThemeChange = (theme: 'light' | 'dark') => {
    setState(prev => ({ ...prev, theme }));
    triggerToast(
      theme === 'light' 
        ? (state.language === 'RU' ? 'Активирована светлая тема' : 'Light theme activated')
        : (state.language === 'RU' ? 'Активирована темная тема' : 'Dark theme activated')
    );
  };

  // Profile Persist
  const handleUpdateProfile = (name: string, email: string) => {
    setState(prev => ({
      ...prev,
      userProfile: { name, email }
    }));
    triggerToast(state.language === 'RU' ? 'Профиль успешно сохранен' : 'Profile saved successfully');
  };

  // Add WhatsApp line modal submit handler
  const handleAddNumberSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNumName.trim() || !newNumPhone.trim()) return;

    const newInst: Instance = {
      id: `inst-${Date.now()}`,
      name: newNumName,
      number: newNumPhone,
      provider: newNumProvider,
      status: 'Waiting QR',
      lastActive: state.language === 'RU' ? 'только что' : 'just now',
      messagesToday: 0,
      createdDate: new Date().toLocaleDateString('ru-RU') + ' ' + new Date().toLocaleTimeString('ru-RU')
    };

    // Append a log entry
    const newLog: LogEntry = {
      id: `log-${Date.now()}`,
      level: 'INFO',
      time: new Date().toLocaleDateString('ru-RU') + ' ' + new Date().toLocaleTimeString('ru-RU'),
      module: 'System',
      message: `Создан новый инстанс "${newNumName}" (${newNumPhone})`,
      resource: `inst_${newInst.id.slice(-4)}`,
      status: 'Success'
    };

    setState(prev => ({
      ...prev,
      instances: [newInst, ...prev.instances],
      logs: [newLog, ...prev.logs],
      selectedInstanceId: newInst.id,
      notificationCount: prev.notificationCount + 1
    }));

    // Reset Form & close
    setNewNumName('');
    setNewNumPhone('+7 900 ');
    setShowAddNumberModal(false);
    
    // Auto navigate to instances view to display scan code
    handleViewChange('instances');
    triggerToast(state.language === 'RU' ? 'Номер добавлен. Отсканируйте QR код' : 'WhatsApp number added. Ready for QR scanning');
  };

  // Instance status modifier from actions
  const handleUpdateInstanceStatus = (id: string, status: Instance['status']) => {
    setState(prev => {
      const updated = prev.instances.map(inst => 
        inst.id === id ? { ...inst, status, lastActive: state.language === 'RU' ? 'только что' : 'just now' } : inst
      );

      const target = prev.instances.find(i => i.id === id);
      const newLog: LogEntry = {
        id: `log-${Date.now()}`,
        level: status === 'Disconnected' ? 'WARNING' : 'INFO',
        time: new Date().toLocaleDateString('ru-RU') + ' ' + new Date().toLocaleTimeString('ru-RU'),
        module: 'WhatsApp',
        message: `Инстанс "${target?.name || ''}" изменил статус на ${status}`,
        resource: `inst_${id.slice(-4)}`,
        status: 'Success'
      };

      return {
        ...prev,
        instances: updated,
        logs: [newLog, ...prev.logs]
      };
    });

    triggerToast(
      state.language === 'RU' 
        ? `Статус инстанса изменен на ${status}` 
        : `Instance status updated to ${status}`
    );
  };

  // Add Messages to conversations list
  const handleAddMessage = (msg: Message) => {
    setState(prev => {
      // Create system log
      const newLog: LogEntry = {
        id: `log-${Date.now()}`,
        level: 'INFO',
        time: new Date().toLocaleDateString('ru-RU') + ' ' + new Date().toLocaleTimeString('ru-RU'),
        module: 'API',
        message: `Сообщение отправлено на ${msg.number}. Текст: "${msg.messageText.substring(0, 30)}..."`,
        resource: `inst_${prev.selectedInstanceId?.slice(-4) || '01'}`,
        status: 'Success'
      };

      return {
        ...prev,
        messages: [msg, ...prev.messages],
        logs: [newLog, ...prev.logs]
      };
    });
    triggerToast(state.language === 'RU' ? 'Сообщение доставлено' : 'Message dispatched');
  };

  // Add API token
  const handleAddToken = (token: ApiToken) => {
    setState(prev => ({
      ...prev,
      tokens: [token, ...prev.tokens],
      selectedTokenId: token.id
    }));
    triggerToast(state.language === 'RU' ? 'Новый секретный API токен сгенерирован' : 'New secret API token issued');
  };

  // Revoke token
  const handleRevokeToken = (id: string) => {
    setState(prev => {
      const updated = prev.tokens.map(t => 
        t.id === id ? { ...t, status: 'Отозван' as const } : t
      );
      const target = prev.tokens.find(t => t.id === id);

      const newLog: LogEntry = {
        id: `log-${Date.now()}`,
        level: 'WARNING',
        time: new Date().toLocaleDateString('ru-RU') + ' ' + new Date().toLocaleTimeString('ru-RU'),
        module: 'API',
        message: `API токен "${target?.name || ''}" отозван администратором`,
        resource: 'system',
        status: 'Success'
      };

      return {
        ...prev,
        tokens: updated,
        logs: [newLog, ...prev.logs]
      };
    });
    triggerToast(state.language === 'RU' ? 'API токен успешно отозван' : 'API token access revoked');
  };

  // Add Webhook
  const handleAddWebhook = (wh: Webhook) => {
    setState(prev => ({
      ...prev,
      webhooks: [wh, ...prev.webhooks],
      selectedWebhookId: wh.id
    }));
    triggerToast(state.language === 'RU' ? 'Конфигурация Webhook добавлена' : 'Webhook destination added');
  };

  // Toggle webhook status
  const handleToggleWebhookActive = (id: string) => {
    setState(prev => {
      const updated = prev.webhooks.map(w => 
        w.id === id ? { ...w, active: !w.active } : w
      );
      const target = prev.webhooks.find(w => w.id === id);

      return {
        ...prev,
        webhooks: updated
      };
    });
    triggerToast(state.language === 'RU' ? 'Статус Webhook изменен' : 'Webhook toggle status modified');
  };

  // Clear system logs
  const handleClearLogs = () => {
    setState(prev => ({ ...prev, logs: [], selectedLogId: null }));
    triggerToast(state.language === 'RU' ? 'Системные логи очищены' : 'All local system log feeds erased');
  };

  // Select Item Details wrappers
  const handleSelectInstance = (id: string | null) => {
    setState(prev => ({ ...prev, selectedInstanceId: id }));
  };
  const handleSelectMessage = (id: string | null) => {
    setState(prev => ({ ...prev, selectedMessageId: id }));
  };
  const handleSelectToken = (id: string | null) => {
    setState(prev => ({ ...prev, selectedTokenId: id }));
  };
  const handleSelectWebhook = (id: string | null) => {
    setState(prev => ({ ...prev, selectedWebhookId: id }));
  };
  const handleSelectLog = (id: string | null) => {
    setState(prev => ({ ...prev, selectedLogId: id }));
  };

  // Render Page Content based on active view state
  const renderViewContent = () => {
    switch (state.activeView) {
      case 'overview':
        return (
          <OverviewView 
            state={state} 
            onViewChange={handleViewChange}
            onAddNumberClick={() => setShowAddNumberModal(true)}
          />
        );
      case 'instances':
        return (
          <InstancesView 
            state={state}
            onSelectInstance={handleSelectInstance}
            onAddNumberClick={() => setShowAddNumberModal(true)}
            onUpdateInstanceStatus={handleUpdateInstanceStatus}
          />
        );
      case 'messages':
        return (
          <MessagesView 
            state={state}
            onSelectMessage={handleSelectMessage}
            onAddMessage={handleAddMessage}
            onSendMessageClick={() => triggerToast(state.language === 'RU' ? 'Выберите нужного клиента для отправки сообщения' : 'Select client to start messaging')}
          />
        );
      case 'tokens':
        return (
          <TokensView 
            state={state}
            onSelectToken={handleSelectToken}
            onAddToken={handleAddToken}
            onRevokeToken={handleRevokeToken}
          />
        );
      case 'webhooks':
        return (
          <WebhooksView 
            state={state}
            onSelectWebhook={handleSelectWebhook}
            onAddWebhook={handleAddWebhook}
            onToggleWebhookActive={handleToggleWebhookActive}
          />
        );
      case 'logs':
        return (
          <LogsView 
            state={state}
            onSelectLog={handleSelectLog}
            onClearLogs={handleClearLogs}
          />
        );
      case 'settings':
        return (
          <SettingsView 
            state={state}
            onUpdateProfile={handleUpdateProfile}
            onUpdateLanguage={handleLanguageChange}
            onUpdateTheme={handleThemeChange}
          />
        );
      default:
        return (
          <div className="text-center py-20 text-gray-400 font-semibold text-sm">
            {state.language === 'RU' ? 'Раздел в разработке' : 'Section under development'}
          </div>
        );
    }
  };

  const isRu = state.language === 'RU';

  return (
    <Layout
      state={state}
      onViewChange={handleViewChange}
      onSearchChange={handleSearchChange}
      onLanguageChange={handleLanguageChange}
      onThemeChange={handleThemeChange}
    >
      {/* Dynamic Main Page Content */}
      {renderViewContent()}

      {/* Floating Animated success Toast Notification popup */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 bg-gray-900 text-white rounded-2xl p-4 shadow-2xl border border-gray-800 z-50 flex items-center gap-3 animate-slide-up max-w-sm text-xs font-semibold">
          <div className="w-5 h-5 rounded-full bg-emerald-500 text-white flex items-center justify-center font-bold text-xs">
            ✓
          </div>
          <span className="flex-1 text-gray-100">{toastMessage}</span>
        </div>
      )}

      {/* Modal Dialog: Add WhatsApp Number */}
      {showAddNumberModal && (
        <div className="fixed inset-0 bg-gray-950/40 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-slate-900 border border-gray-100 dark:border-slate-800 rounded-3xl w-full max-w-md p-6 shadow-2xl relative animate-scale-up text-left">
            {/* Close */}
            <button 
              onClick={() => setShowAddNumberModal(false)}
              className="absolute top-5 right-5 text-gray-400 hover:text-gray-700 dark:hover:text-white w-8 h-8 rounded-full hover:bg-gray-50 dark:hover:bg-slate-800 flex items-center justify-center cursor-pointer text-sm font-semibold"
            >
              ✕
            </button>

            {/* Title */}
            <div className="flex items-center gap-2.5 pb-4 border-b border-gray-50 dark:border-slate-800 mb-5">
              <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center">
                <Smartphone className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-gray-900 dark:text-white">
                  {isRu ? 'Добавить WhatsApp номер' : 'Add WhatsApp Line'}
                </h3>
                <p className="text-[10px] text-gray-400 dark:text-slate-500 mt-0.5">
                  {isRu ? 'Интеграция нового канала связи' : 'Integrate new WhatsApp channel'}
                </p>
              </div>
            </div>

            {/* Form */}
            <form onSubmit={handleAddNumberSubmit} className="space-y-4">
              {/* Name */}
              <div className="space-y-1">
                <label className="block text-xs font-bold text-gray-400 dark:text-slate-500 uppercase">
                  {isRu ? 'Название инстанса' : 'Instance name'}
                </label>
                <input
                  type="text"
                  required
                  value={newNumName}
                  onChange={(e) => setNewNumName(e.target.value)}
                  placeholder={isRu ? "Например, Sales Bot, Support Line..." : "e.g., Sales Bot"}
                  className="w-full bg-gray-50 dark:bg-slate-950 border border-gray-100 dark:border-slate-800 rounded-xl py-2.5 px-3 text-xs text-gray-800 dark:text-white focus:outline-hidden focus:border-blue-500 focus:bg-white dark:focus:bg-slate-900"
                />
              </div>

              {/* Phone number */}
              <div className="space-y-1">
                <label className="block text-xs font-bold text-gray-400 dark:text-slate-500 uppercase">
                  {isRu ? 'Номер телефона' : 'Phone Number'}
                </label>
                <input
                  type="text"
                  required
                  value={newNumPhone}
                  onChange={(e) => setNewNumPhone(e.target.value)}
                  placeholder="+7 999 123-45-67"
                  className="w-full bg-gray-50 dark:bg-slate-950 border border-gray-100 dark:border-slate-800 rounded-xl py-2.5 px-3 text-xs text-gray-800 dark:text-white font-mono focus:outline-hidden focus:border-blue-500 focus:bg-white dark:focus:bg-slate-900"
                />
              </div>



              {/* Provider */}
              <div className="space-y-1">
                <label className="block text-xs font-bold text-gray-400 dark:text-slate-500 uppercase">
                  {isRu ? 'Провайдер авторизации' : 'Authorization Provider'}
                </label>
                <select
                  value={newNumProvider}
                  onChange={(e) => setNewNumProvider(e.target.value)}
                  className="w-full bg-gray-50 dark:bg-slate-950 border border-gray-100 dark:border-slate-800 rounded-xl py-2.5 px-3 text-xs text-gray-700 dark:text-slate-300 font-semibold focus:outline-hidden focus:border-blue-500"
                >
                  <option value="Baileys">Baileys (Web Multi-Device)</option>
                  <option value="Official">Official (WhatsApp Business Cloud API)</option>
                </select>
              </div>

              {/* Disclaimer */}
              <div className="bg-amber-50 dark:bg-amber-950/30 border border-amber-100/50 dark:border-amber-900/40 rounded-xl p-3 flex gap-2.5 text-[10.5px] leading-relaxed text-amber-800 dark:text-amber-400">
                <ShieldAlert className="w-4 h-4 text-amber-600 dark:text-amber-500 shrink-0 mt-0.5" />
                <p>
                  {isRu 
                    ? 'При создании будет подготовлен инстанс в статусе "Waiting QR". Вы сможете сразу отсканировать QR код для подключения к WhatsApp.' 
                    : 'A new routing line will be provisioned. Scan the QR code in the next window to finalize device links.'
                  }
                </p>
              </div>

              {/* Actions */}
              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddNumberModal(false)}
                  className="flex-1 py-2.5 border border-gray-200 dark:border-slate-800 hover:bg-gray-50 dark:hover:bg-slate-800 text-gray-700 dark:text-slate-300 text-xs font-bold rounded-xl transition-colors cursor-pointer"
                >
                  {isRu ? 'Отмена' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl transition-colors shadow-sm shadow-blue-100 dark:shadow-none cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>{isRu ? 'Подключить' : 'Add Line'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </Layout>
  );
}
